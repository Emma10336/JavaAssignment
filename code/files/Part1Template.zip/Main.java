
public class Main {

	public static void main(String[] args) {
		
		//ask for players name and insert this into the constructor

		GameSetup gs = new GameSetup("Hiran", 3, 10);
		gs.startGame();
		
	}

}
