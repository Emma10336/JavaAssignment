import java.util.LinkedList;

public class GameSetup {

	private String playerName;
	private int totalLives;
	private int maxQuestions;

	public GameSetup(String name, int lives, int numQuestions) {
		this.playerName = name;
		this.totalLives = lives;
		this.maxQuestions = numQuestions;
	}

	void startGame() {

		GameFunctions gf = new GameFunctions();

		LinkedList<String> csvFileNames = new LinkedList<>();
		csvFileNames.add("C:\\Users\\Hiran\\eclipse-workspace\\5CS019AssessmentP1\\src\\sport.csv"); // Replace with the
																										// actual CSV
																										// file names
		csvFileNames.add("C:\\Users\\Hiran\\eclipse-workspace\\5CS019AssessmentP1\\src\\science.csv");
		csvFileNames.add("C:\\Users\\Hiran\\eclipse-workspace\\5CS019AssessmentP1\\src\\movie.csv");
		csvFileNames.add("C:\\Users\\Hiran\\eclipse-workspace\\5CS019AssessmentP1\\src\\history.csv");
		csvFileNames.add("C:\\Users\\Hiran\\eclipse-workspace\\5CS019AssessmentP1\\src\\geog.csv");
		// Add more CSV file names as needed
		// the above could be turned into a function to read all CSV files from a
		// specific folder using the OS

		Read read = new Read(csvFileNames);

		LinkedList<LinkedList<String>> questions = new LinkedList<LinkedList<String>>();
		LinkedList<LinkedList<String>> answers = new LinkedList<LinkedList<String>>();

		questions = read.readQuestionsFromMultipleCSVs();
		answers = read.readAnswersFromMultipleCSVs();

		int randomQuestionNumber = gf.rollDice(1, 5); // yours needs to be 1 to 6, i only have 5 categories!
		int randomAnswerNumber = gf.rollDice(1, 10);

		// create the game here

	}

}
