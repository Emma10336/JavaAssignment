import java.util.LinkedList;

public class Write {

	void addQandASingleToCSV(String question, String answer, String CSVPath) {
		// Your function should auto add the ID by checking the last row in the data and
		// adding one to the previous ID
		// Do some error checks which are sensible such as checking for blank questions
		// and/or blank answers
	}

	void addQandAMultipleToCSV(LinkedList<String> questions, LinkedList<String> answers, String CSVPath) {
		// add a list of questions and answers.
		// you will need to auto generate the row ID for each question and answer that
		// you add
	}

}
