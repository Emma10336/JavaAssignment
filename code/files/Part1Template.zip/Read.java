import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class Read {

	private String path;
	private LinkedList<String> csvFileNames;
	private String[] tableNames;

	public Read(String constructorPath) { // use this constructor when you just want to use
		this.path = constructorPath;
	}

	public Read(LinkedList<String> constructorCSVFilePaths) {
		this.csvFileNames = constructorCSVFilePaths;
	}

	public Read(String[] constructorTableNames) { // this is for the MySQL part. Can't use LinkedList as we have already
													// a constructor which has a linkedList for the csv version
		this.tableNames = constructorTableNames;
	}

	public LinkedList<String> readAllQuestionsFromCSV() {

		LinkedList<String> questions = new LinkedList<>();
		return questions;

	}

	public LinkedList<String> readAllAnswersFromCSV() {

		LinkedList<String> answers = new LinkedList<>();
		return answers;

	}

	public LinkedList<LinkedList<String>> readQuestionsFromMultipleCSVs() {
		LinkedList<LinkedList<String>> result = new LinkedList<>();
		return result;
	}

	public LinkedList<LinkedList<String>> readAnswersFromMultipleCSVs() {
		LinkedList<LinkedList<String>> result = new LinkedList<>();
		return result;
	}

}
