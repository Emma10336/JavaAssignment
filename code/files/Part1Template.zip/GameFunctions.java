import java.util.LinkedList;
import java.util.Random;

public class GameFunctions {

	Random random = new Random();

	LinkedList<String> pickQuestionAndAnswer(LinkedList<String> questions, LinkedList<String> answers, int randomNum) {
		// select a random question with the answer and return it as a linkedlist. 0 ->
		// q and 1 -> a.
		return null;
	}

	public int rollDice(int min, int max) {
		//create random number generator
		return 0;
	}

	boolean checkAnswers(String userInput, String realAnswer) { // you may want to add an extra parameter to check original list rather
												// than just a single question and answer
		// check if the correct answer is given for a specific question
		return false;
	}

}
